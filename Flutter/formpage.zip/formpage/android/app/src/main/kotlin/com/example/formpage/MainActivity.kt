package com.example.formpage

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
